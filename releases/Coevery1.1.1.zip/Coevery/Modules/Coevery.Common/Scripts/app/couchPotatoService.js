define(['app'], function(app) {
    return app.couchPotato;
});
