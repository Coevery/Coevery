define(['app'], function(app) {
  return app.detour;
});
